<?php
require 'config.php';
if(logged_in()){header('Location:index.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){csrf_check();
$name=trim($_POST['full_name']??''); $phone=preg_replace('/\D+/','',$_POST['phone']??''); $pass=$_POST['password']??'';
if(strlen($name)<5 || count(preg_split('/\s+/', $name))<3) $error='Andika majina matatu.';
elseif(strlen($phone)<9 || strlen($phone)>15) $error='Namba ya simu si sahihi.';
elseif(strlen($pass)<4) $error='Password iwe na angalau tarakimu/herufi 4.';
else { try { $s=db()->prepare("INSERT INTO users(full_name,phone,password_hash,role,credits,status) VALUES(?,?,?,'user',0,'active')"); $s->execute([$name,$phone,password_hash($pass,PASSWORD_DEFAULT)]); flash('Usajili umefanikiwa. Ingia sasa.'); header('Location:login.php');exit; } catch(PDOException $e){$error='Namba hii imeshasajiliwa.';} }
}
layout_start('Jisajili'); echo '<div class="auth"><h1>Fungua akaunti</h1>'.($error?'<div class="error">'.e($error).'</div>':'').'<form method="post"><input type="hidden" name="csrf" value="'.csrf_token().'"><label>Majina matatu</label><input name="full_name" required placeholder="Jina la kwanza la pili la tatu"><label>Namba ya simu</label><input name="phone" inputmode="tel" required><label>Password (angalau 4)</label><input type="password" name="password" minlength="4" required><button class="btn wide">Jisajili</button></form><p>Tayari una akaunti? <a href="login.php">Ingia</a></p></div>'; layout_end();
