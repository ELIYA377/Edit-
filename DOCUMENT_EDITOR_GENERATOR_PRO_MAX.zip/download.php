<?php
require 'config.php'; require_login();
$id=(int)($_GET['id']??0);$s=db()->prepare("SELECT g.*,t.title,t.file_path,t.file_type FROM generated_documents g JOIN templates t ON t.id=g.template_id WHERE g.id=? AND g.user_id=?");$s->execute([$id,$_SESSION['user_id']]);$d=$s->fetch();if(!$d){http_response_code(404);exit('Document haipatikani.');}
$data=json_decode($d['data_json'],true)?:[];
layout_start('Pakua Document');echo '<div class="downloadbar"><h1>'.e($d['title']).'</h1><button class="btn" onclick="window.print()">Pakua / Print PDF</button><a class="btn secondary" href="index.php">Rudi dashboard</a></div><article class="output">';
if($d['file_type']==='image')echo '<img class="output-bg" src="'.e($d['file_path']).'">';
else echo '<p class="notice">Hii ni PDF ya chanzo. Itafunguka kwenye dirisha tofauti; tumia Print/Save as PDF. Kwa layout sahihi ya maandishi juu ya template, tumia template ya PNG/JPG.</p><iframe class="output-pdf" src="'.e($d['file_path']).'"></iframe>';
echo '<div class="output-data">';
foreach($data as $k=>$v)echo '<p><strong>'.e(ucwords(str_replace('_',' ',$k))).':</strong> '.e($v).'</p>';
echo '</div></article><style>@media print{.top,footer,.downloadbar{display:none!important}.wrap{max-width:none;padding:0}.output{box-shadow:none}}</style>';layout_end();
