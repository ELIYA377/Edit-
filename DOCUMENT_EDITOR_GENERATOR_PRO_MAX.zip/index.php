<?php
require 'config.php';
if (!logged_in()) { header('Location: login.php'); exit; }
require_login();
$templates=db()->query("SELECT t.*, u.full_name AS owner FROM templates t LEFT JOIN users u ON u.id=t.created_by WHERE t.active=1 ORDER BY t.created_at DESC")->fetchAll();
layout_start('Dashboard');
echo '<section class="hero"><div><span class="tag">WORKSPACE</span><h1>Karibu, '.e($_SESSION['full_name']).'</h1><p>Chagua template halali ya biashara au nyaraka zako, jaza taarifa na tengeneza nakala yako.</p></div><div class="credit"><small>Salio la credits</small><strong>'.(int)($_SESSION['credits']??0).'</strong></div></section>';
echo '<h2>Templates zinazopatikana</h2><div class="grid">';
foreach($templates as $t){ echo '<article class="card"><div class="thumb">';
if($t['file_type']==='image') echo '<img src="'.e($t['file_path']).'" alt="">'; else echo '<div class="pdf">PDF</div>';
echo '</div><div class="pad"><h3>'.e($t['title']).'</h3><p>'.e($t['description']).'</p><a class="btn" href="editor.php?id='.(int)$t['id'].'">Fungua editor</a></div></article>'; }
if(!$templates) echo '<div class="empty">Bado hakuna templates. Admin anaweza kuongeza templates kupitia sehemu ya Templates.</div>';
echo '</div>';
layout_end();
