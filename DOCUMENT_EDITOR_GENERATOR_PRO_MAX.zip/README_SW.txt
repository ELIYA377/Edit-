DOCUMENT EDITOR & GENERATOR PRO MAX
==================================

MUHIMU:
- Mfumo huu ni starter version ya templates halali za biashara/nyaraka zako mwenyewe.
- Usitumie kubadilisha au kuiga leseni, vyeti, vitambulisho au nyaraka rasmi zilizotolewa na mamlaka.
- PNG/JPG: live preview na taarifa zinaweza kuonekana kwenye template. PDF: inaonyeshwa kama chanzo; kwa maandishi yaliyopangwa juu yake, export PDF-to-image kwanza kisha upload PNG/JPG.

INSTALLATION INFINITYFREE
1. Fungua File Manager > htdocs.
2. Upload ZIP na extract yaliyomo moja kwa moja ndani ya htdocs. Hakikisha index.php iko ndani ya htdocs, si ndani ya folder la ziada.
3. Fungua phpMyAdmin ya database if0_43423383_Genereter.
4. Chagua Import, kisha import install.sql.
5. Fungua config.php na badilisha WEKA_MYSQL_PASSWORD_HAPA kwa password yako ya MySQL.
6. Fungua https://DOMAIN-YAKO/setup_admin.php na tengeneza admin (password ya admin angalau herufi 10).
7. Baada ya admin kuundwa, FUTA setup_admin.php kupitia File Manager.
8. Ingia kupitia login.php. Admin ataona Templates na Admin kwenye menyu.

TEMPLATE FIELDS
Kwenye Template Manager, andika field moja kwa kila mstari:
Jina la Biashara|business_name|text
Tarehe|issue_date|date
Namba ya Simu|phone|text
Aina zinazokubalika: text, date, number.

USALAMA
- Password huhifadhiwa kwa password_hash.
- Usitumie password fupi ya admin.
- Usishiriki config.php au MySQL password.
- Mfumo wa credits ni sehemu ya msingi ya akaunti/admin; malipo ya credits na makato ya kila download bado hayajaunganishwa kwenye toleo hili.
