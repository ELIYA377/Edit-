<?php
require 'config.php';
$count=(int)db()->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
$msg='';
if($count===0 && $_SERVER['REQUEST_METHOD']==='POST'){csrf_check();$name=trim($_POST['name']??'');$phone=preg_replace('/\D+/','',$_POST['phone']??'');$pass=$_POST['password']??'';
if(strlen($name)<5 || count(preg_split('/\s+/', $name))<3 || strlen($phone)<9 || strlen($pass)<10){$msg='Jaza majina matatu, simu sahihi na password yenye angalau herufi 10.';}
else{try{$s=db()->prepare("INSERT INTO users(full_name,phone,password_hash,role,credits,status) VALUES(?,?,?,'admin',0,'active')");$s->execute([$name,$phone,password_hash($pass,PASSWORD_DEFAULT)]);$msg='Admin ameundwa. Futa setup_admin.php sasa hivi.';}catch(Throwable $e){$msg='Imeshindikana kuhifadhi admin. Hakikisha simu haijatumika.';}}
}
layout_start('Setup Admin'); echo '<div class="auth"><h1>Unda Super Admin</h1><p>Ukurasa huu ufanye kazi mara moja tu baada ya ku-import SQL.</p><div class="notice">'.e($msg?:($count?'Admin tayari yupo. Futa setup_admin.php.':'Hakuna admin bado.')).'</div>';
if(!$count) echo '<form method="post"><input type="hidden" name="csrf" value="'.csrf_token().'"><label>Majina matatu</label><input name="name" required><label>Namba ya simu</label><input name="phone" required><label>Password (angalau 10)</label><input type="password" name="password" minlength="10" required><button class="btn wide">Unda Admin</button></form>';
echo '</div>'; layout_end();
