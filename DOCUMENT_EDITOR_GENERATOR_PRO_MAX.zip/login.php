<?php
require 'config.php';
if(logged_in()){header('Location:index.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){csrf_check(); $phone=preg_replace('/\D+/','',$_POST['phone']??''); $pass=$_POST['password']??'';
$s=db()->prepare("SELECT * FROM users WHERE phone=? LIMIT 1");$s->execute([$phone]);$u=$s->fetch();
if($u && $u['status']==='active' && password_verify($pass,$u['password_hash'])){session_regenerate_id(true);$_SESSION['user_id']=$u['id'];$_SESSION['full_name']=$u['full_name'];$_SESSION['role']=$u['role'];$_SESSION['credits']=$u['credits'];header('Location:index.php');exit;} $error='Namba ya simu au password si sahihi, au akaunti imesimamishwa.';
}
layout_start('Ingia'); echo '<div class="auth"><h1>Ingia kwenye akaunti</h1>'.($m=flash()?'<div class="notice">'.e($m).'</div>':'').($error?'<div class="error">'.e($error).'</div>':'').'<form method="post"><input type="hidden" name="csrf" value="'.csrf_token().'"><label>Namba ya simu</label><input name="phone" inputmode="tel" required><label>Password</label><input type="password" name="password" required><button class="btn wide">Ingia</button></form><p>Huna akaunti? <a href="register.php">Jisajili</a></p></div>'; layout_end();
