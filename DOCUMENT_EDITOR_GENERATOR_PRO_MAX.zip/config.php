<?php
// Weka MySQL password yako hapa. Usishiriki password hadharani.
define('DB_HOST', 'sql106.infinityfree.com');
define('DB_NAME', 'if0_43423383_Genereter');
define('DB_USER', 'if0_43423383');
define('DB_PASS', 'WEKA_MYSQL_PASSWORD_HAPA');
define('APP_NAME', 'DOCUMENT EDITOR & GENERATOR PRO MAX');
define('BASE_URL', ''); // Acha tupu ikiwa app iko kwenye public_html/htdocs root.
date_default_timezone_set('Africa/Dar_es_Salaam');
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_strict_mode', '1');
    session_start();
}
function db() {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }
    return $pdo;
}
function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function logged_in() { return !empty($_SESSION['user_id']); }
function is_admin() { return !empty($_SESSION['role']) && $_SESSION['role'] === 'admin'; }
function require_login() { if (!logged_in()) { header('Location: login.php'); exit; } }
function require_admin() { require_login(); if (!is_admin()) { http_response_code(403); exit('Huna ruhusa.'); } }
function csrf_token() { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_check() { if ($_SERVER['REQUEST_METHOD']==='POST' && !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('Ombi limeisha muda. Refresh ukurasa.'); } }
function flash($msg=null) { if ($msg!==null) { $_SESSION['flash']=$msg; return; } $m=$_SESSION['flash']??''; unset($_SESSION['flash']); return $m; }
function layout_start($title='') {
    $name=e(APP_NAME); $t=e($title);
    echo '<!doctype html><html lang="sw"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.$t.' | '.$name.'</title><link rel="stylesheet" href="assets/style.css"></head><body><header class="top"><a class="brand" href="index.php">'.$name.'</a><nav>';
    if (logged_in()) { echo '<a href="index.php">Dashboard</a>'; if (is_admin()) echo '<a href="templates.php">Templates</a><a href="admin.php">Admin</a>'; echo '<a href="logout.php">Toka</a>'; }
    else echo '<a href="login.php">Ingia</a><a href="register.php">Jisajili</a>';
    echo '</nav></header><main class="wrap">';
    if ($m=flash()) echo '<div class="notice">'.e($m).'</div>';
}
function layout_end() { echo '</main><footer>© '.date('Y').' '.e(APP_NAME).'</footer></body></html>'; }
