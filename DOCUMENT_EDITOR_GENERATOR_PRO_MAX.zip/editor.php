<?php
require 'config.php'; require_login();
$id=(int)($_GET['id']??0);$s=db()->prepare("SELECT * FROM templates WHERE id=? AND active=1");$s->execute([$id]);$t=$s->fetch();if(!$t){http_response_code(404);exit('Template haipatikani.');}
$fields=json_decode($t['fields_json'],true)?:[];
if($_SERVER['REQUEST_METHOD']==='POST'){csrf_check();$data=[];foreach($fields as $f){$key=$f['key'];$data[$key]=trim($_POST[$key]??'');}
$ins=db()->prepare("INSERT INTO generated_documents(user_id,template_id,data_json) VALUES(?,?,?)");$ins->execute([$_SESSION['user_id'],$id,json_encode($data,JSON_UNESCAPED_UNICODE)]);$doc=$pdoid=db()->lastInsertId();header('Location:download.php?id='.(int)$doc);exit;}
layout_start('Editor');echo '<div class="editor-head"><div><span class="tag">LIVE EDITOR</span><h1>'.e($t['title']).'</h1><p>'.e($t['description']).'</p></div><button type="button" class="btn" onclick="document.getElementById(\'editForm\').classList.toggle(\'hidden\')">EDIT / JAZA TAARIFA</button></div><div class="editor-layout"><section class="preview">';
if($t['file_type']==='image') echo '<div class="paper" id="paper"><img src="'.e($t['file_path']).'" alt="Template">'.'<div id="overlay"></div></div>';
else echo '<div class="pdfnotice"><b>PDF template</b><p>PDF inaonyeshwa hapa kama chanzo. Kwa kuweka maandishi kwenye nafasi maalum na live overlay, admin anapaswa kupakia pia ukurasa wake kama PNG/JPG.</p><iframe src="'.e($t['file_path']).'" title="PDF template"></iframe></div>';
echo '</section><aside id="editForm" class="formpanel hidden"><h2>Jaza taarifa</h2><form method="post" id="docForm"><input type="hidden" name="csrf" value="'.csrf_token().'">';
foreach($fields as $f){$k=e($f['key']);$lab=e($f['label']);$type=e($f['type']);echo '<label>'.$lab.'</label><input name="'.$k.'" data-key="'.$k.'" type="'.$type.'" oninput="updatePreview()" required>';}
if(!$fields) echo '<p>Admin hajaweka fields kwenye template hii.</p>';
echo '<button class="btn wide" '.(!$fields?'disabled':'').'>Tengeneza na pakua</button></form></aside></div><script>function updatePreview(){const o=document.getElementById("overlay");if(!o)return;o.innerHTML="";document.querySelectorAll("#docForm input[data-key]").forEach((el,i)=>{if(el.value){const d=document.createElement("div");d.className="overlay-text";d.style.top=(8+i*7)+"%";d.style.left="8%";d.textContent=el.value;o.appendChild(d)}})}</script>';layout_end();
