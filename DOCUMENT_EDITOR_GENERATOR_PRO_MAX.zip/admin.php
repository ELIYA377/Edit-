<?php
require 'config.php'; require_admin();
if($_SERVER['REQUEST_METHOD']==='POST'){csrf_check();$id=(int)($_POST['id']??0);$action=$_POST['action']??'';
if($action==='credits'){$n=max(0,(int)($_POST['credits']??0));db()->prepare("UPDATE users SET credits=? WHERE id=? AND role='user'")->execute([$n,$id]);flash('Credits zimebadilishwa.');}
if($action==='status'){db()->prepare("UPDATE users SET status=? WHERE id=? AND role='user'")->execute([$_POST['status']==='active'?'active':'suspended',$id]);flash('Hali ya akaunti imebadilishwa.');}
header('Location:admin.php');exit;}
$users=db()->query("SELECT id,full_name,phone,credits,status,created_at FROM users WHERE role='user' ORDER BY id DESC")->fetchAll();
$docs=(int)db()->query("SELECT COUNT(*) FROM generated_documents")->fetchColumn();
$temps=(int)db()->query("SELECT COUNT(*) FROM templates")->fetchColumn();
layout_start('Admin Dashboard');
echo '<section class="hero"><div><span class="tag">ADMIN CONTROL</span><h1>Dashboard ya Admin</h1><p>Simamia akaunti, credits na templates.</p></div></section><div class="stats"><div><b>'.count($users).'</b><span>Watumiaji</span></div><div><b>'.$temps.'</b><span>Templates</span></div><div><b>'.$docs.'</b><span>Nyaraka</span></div></div><p><a class="btn" href="templates.php">+ Simamia templates</a></p><h2>Watumiaji</h2><div class="tablewrap"><table><tr><th>Jina</th><th>Simu</th><th>Credits</th><th>Hali</th><th>Vitendo</th></tr>';
foreach($users as $u){echo '<tr><td>'.e($u['full_name']).'</td><td>'.e($u['phone']).'</td><td>'.(int)$u['credits'].'</td><td>'.e($u['status']).'</td><td><form class="inline" method="post"><input type="hidden" name="csrf" value="'.csrf_token().'"><input type="hidden" name="id" value="'.$u['id'].'"><input type="number" min="0" name="credits" value="'.(int)$u['credits'].'" class="small"><button name="action" value="credits" class="btn mini">Hifadhi credits</button><button name="action" value="status" value="suspended" class="btn mini secondary">Badili hali</button><input type="hidden" name="status" value="'.($u['status']==='active'?'suspended':'active').'"></form></td></tr>';}
echo '</table></div>';layout_end();
